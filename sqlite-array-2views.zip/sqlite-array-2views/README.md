# ANDROID-sqlite
This project show how manipulate data with SQLite

Este projeto mostra com realizar a inclusão e consulta de dados com o SQLite no Android
