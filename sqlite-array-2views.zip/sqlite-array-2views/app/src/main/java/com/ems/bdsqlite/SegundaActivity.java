package com.ems.bdsqlite;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SegundaActivity extends AppCompatActivity {

    EditText ra, nome, curso, campus;
    Aluno a;
    TextView erro;
    Button alterar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        alterar = findViewById(R.id.btAlterar);
        erro = findViewById(R.id.msgErro);
        ra = findViewById(R.id.editRa2);
        nome = findViewById(R.id.editNome2);
        curso = findViewById(R.id.editCurso2);
        campus = findViewById(R.id.editCampus2);

        Intent it = getIntent();
        a = (Aluno) getIntent().getSerializableExtra("infoAluno");

        ra.setText(a.getRa());
        nome.setText(a.getNome());
        curso.setText(a.getCurso());
        campus.setText(a.getCampus());

        alterar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ra.getText().toString().isEmpty() | nome.getText().toString().isEmpty()
                | campus.getText().toString().isEmpty() |curso.getText().toString().isEmpty()){
                    erro.setText("Campo em branco detectado!");
                }else{
                    erro.setText("Alterado com sucesso!");
                }
            }
        });
    }
}

