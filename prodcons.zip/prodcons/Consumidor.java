package br.com.prodcons;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Consumidor implements Runnable {

    Valores valor;

    public Consumidor(Valores valor) {
        this.valor = valor;
    }

    @Override
    public void run() {
        int tempo, i;

        for (i = 0; i <= 10; i++) {
            tempo = (int) (Math.random() * 3000);
            System.out.println("O Consumidor está lendo o valor: "
                    + valor.getValor()
            );
            try {
                Thread.sleep(tempo);
            } catch (InterruptedException ex) {
                Logger.getLogger(Consumidor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

}
