package br.com.prodcons;

public class Processo {
    public static void main(String[] args) {
        Valores valor = new Valores();
        
        System.out.println("Iniciando Threads Produtor e Consumidor");
        System.out.println("=======================================");
        
        new Thread(new Produtor(valor)).start();
        new Thread(new Consumidor(valor)).start();
        
    }
}
