package br.com.prodcons;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Valores {
    
    int valor;
    private boolean bloqueado;
    
    public Valores(){
        bloqueado = false;
    }

    public synchronized int getValor() {
        while(!bloqueado){
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Valores.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        bloqueado = false;
        notify();
        return valor;
    }

    public synchronized void setValor(int valor) {
        while(bloqueado){
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Valores.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        this.valor = valor;
        bloqueado = true;
        notify();
    }
    
     
}
